package com.volt.gui;

import com.volt.Volt;
import com.volt.gui.animation.AnimationManager;
import com.volt.gui.components.SettingsRenderer;
import com.volt.gui.components.UIRenderer;
import com.volt.gui.events.GuiEventHandler;
import com.volt.gui.utils.SearchUtils;
import com.volt.module.Category;
import com.volt.module.Module;
import com.volt.module.modules.client.ClickGUIModule;
import com.volt.module.setting.NumberSetting;
import com.volt.utils.font.FontManager;
import com.volt.utils.font.fonts.FontRenderer;
import com.volt.utils.render.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ClickGui extends Screen {
    private static Category lastSelectedCategory = Category.COMBAT;
    private static final Map<Module, Boolean> lastModuleExpanded = new HashMap<>();
    private static int lastScrollOffset = 0;
    private static final int SIDEBAR_WIDTH = 180;
    private static final int CONTAINER_WIDTH = SIDEBAR_WIDTH + 600;
    private static final int COLOR_PICKER_PANEL_WIDTH = 250;
    private static final int HEADER_HEIGHT = 60;
    private static final int MODULE_HEIGHT = 35;
    private static final int PADDING = 18;
    private static final int CORNER_RADIUS = 14;
    private final Map<Module, Boolean> moduleExpanded = new HashMap<>();
    private final Map<NumberSetting, Boolean> sliderDragging = new HashMap<>();
    private final ColorPickerManager colorPickerManager;
    private static final int SETTING_HEIGHT = 28;
    private static final int SEARCH_BAR_WIDTH = 200;
    private static final int SEARCH_BAR_HEIGHT = 25;

    private final AnimationManager animationManager;
    private final GuiEventHandler eventHandler;
    private long lastCursorBlink = 0;

    private String configName = "";
    private boolean configNameFocused = false;
    private List<String> configs = new ArrayList<>();
    private String selectedConfig = "";

    private final FontRenderer titleFont;
    private final FontRenderer regularFont;
    private final FontRenderer smallFont;

    public ClickGui() {
        super(Text.empty());

        FontManager fontManager = Volt.INSTANCE.getFontManager();
        this.titleFont = fontManager.getSize(24, FontManager.Type.Poppins);
        this.regularFont = fontManager.getSize(14, FontManager.Type.Inter);
        this.smallFont = fontManager.getSize(12, FontManager.Type.Inter);

        this.animationManager = new AnimationManager();
        this.eventHandler = new GuiEventHandler(moduleExpanded, sliderDragging, lastSelectedCategory);
        this.colorPickerManager = new ColorPickerManager(eventHandler);

        animationManager.initializeGuiAnimation();

        for (Module module : Volt.INSTANCE.getModuleManager().getModules()) {
            moduleExpanded.put(module, lastModuleExpanded.getOrDefault(module, false));
            animationManager.initializeModuleAnimations(module);
        }
        eventHandler.setScrollOffset(lastScrollOffset);

        loadConfigs();
    }

    @Override
    public void init() {
        super.init();
        animationManager.initializeGuiAnimation();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        animationManager.updateAnimations(delta);
        animationManager.updateGuiAnimations(animationManager.getDt());
        eventHandler.updateSmoothScroll(animationManager.getDt());

        if (animationManager.shouldCloseGui()) {
            lastSelectedCategory = eventHandler.getSelectedCategory();
            lastScrollOffset = eventHandler.getScrollOffset();
            lastModuleExpanded.clear();
            lastModuleExpanded.putAll(moduleExpanded);
            Volt.INSTANCE.getModuleManager().getModule(ClickGUIModule.class).get().setEnabled(false);
            super.close();
            return;
        }

        int screenWidth = width;
        int screenHeight = height;

        renderBackground(context, mouseX, mouseY, delta);

        MatrixStack matrices = context.getMatrices();
        matrices.push();

        float centerX = screenWidth / 2f;
        float centerY = screenHeight / 2f;

        matrices.translate(centerX, centerY, 0);
        matrices.scale(animationManager.getScaleAnimation(), animationManager.getScaleAnimation(), 1f);
        matrices.translate(-centerX, -centerY, 0);

        int containerX = (screenWidth - CONTAINER_WIDTH) / 2;
        int containerY = (screenHeight - 500) / 2;
        int containerWidth = CONTAINER_WIDTH;
        int containerHeight = 500;

        float anim = animationManager.getGuiAnimation();

        // Galaxy window: soft shadow, thin glowing border, deep navy -> violet gradient, twinkling stars.
        Theme.drawShadow(context, containerX, containerY, containerWidth, containerHeight, CORNER_RADIUS, anim);
        RenderUtils.drawRoundedBorder(context, containerX, containerY, containerWidth, containerHeight, CORNER_RADIUS, 1,
            Theme.rgb(Theme.alpha(Theme.BORDER, 110), anim));
        RenderUtils.drawRoundedRectVGradient(context, containerX, containerY, containerWidth, containerHeight, CORNER_RADIUS,
            Theme.rgb(Theme.alpha(Theme.BG_TOP, 246), anim), Theme.rgb(Theme.alpha(Theme.BG_BOTTOM, 246), anim));
        Theme.drawStars(context, containerX + 6, containerY + 6, containerWidth - 12, containerHeight - 12, anim);

        renderHeaderBackground(context, containerX, containerY, containerWidth);

        renderSidebar(context, containerX, containerY, containerHeight, mouseX, mouseY);

        renderContent(context, containerX + SIDEBAR_WIDTH, containerY, CONTAINER_WIDTH - SIDEBAR_WIDTH, containerHeight, mouseX, mouseY);

        if (eventHandler.isAnyColorPickerExpanded()) {
            int colorPickerPanelX = containerX + containerWidth + 10;
            colorPickerManager.renderColorPickerPanel(context, colorPickerPanelX, containerY, COLOR_PICKER_PANEL_WIDTH, containerHeight, mouseX, mouseY);
        }

        renderHeader(context, containerX, containerY, containerWidth, mouseX, mouseY);

        matrices.pop();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        float anim = animationManager.getGuiAnimation();
        int backgroundAlpha = (int)(anim * 150);
        RenderUtils.drawGradientRect(context, 0, 0, width, height,
            new Color(4, 5, 20, backgroundAlpha).getRGB(), new Color(24, 10, 48, (int)(backgroundAlpha * 0.8f)).getRGB());
    }

    private void renderHeaderBackground(DrawContext context, int x, int y, int width) {
        float anim = animationManager.getGuiAnimation();
        RenderUtils.drawRoundedRectCorners(context, x, y, width, HEADER_HEIGHT, CORNER_RADIUS, true, false,
            Theme.rgb(Theme.alpha(Theme.HEADER, 190), anim), Theme.rgb(Theme.alpha(Theme.HEADER, 120), anim));
        // Hairline divider with a violet tint.
        context.fill(x + PADDING, y + HEADER_HEIGHT - 1, x + width - PADDING, y + HEADER_HEIGHT,
            Theme.rgb(Theme.alpha(Theme.BORDER, 70), anim));
    }

    private void renderHeader(DrawContext context, int x, int y, int width, int mouseX, int mouseY) {
        float anim = animationManager.getGuiAnimation();
        MatrixStack matrices = context.getMatrices();

        int logoSize = 30;
        Theme.drawLogo(context, x + PADDING, y + (HEADER_HEIGHT - logoSize) / 2, logoSize, anim);

        int titleX = x + PADDING + logoSize + 10;
        int titleY = y + 15;
        int textAlpha = (int)(anim * 255);
        String first = "Astral";
        titleFont.drawString(matrices, first, titleX, titleY, Theme.alpha(Theme.ACCENT_LIGHT, textAlpha));
        titleFont.drawString(matrices, "Client", titleX + titleFont.getStringWidth(first + " "), titleY,
            Theme.alpha(Theme.TEXT, (int)(textAlpha * 0.85f)));

        renderSearchBar(context, x, y, width);
    }

    private void renderSearchBar(DrawContext context, int x, int y, int width) {
        MatrixStack matrices = context.getMatrices();
        float anim = animationManager.getGuiAnimation();

        int searchX = x + width - SEARCH_BAR_WIDTH - PADDING;
        int searchY = y + (HEADER_HEIGHT - SEARCH_BAR_HEIGHT) / 2;

        boolean focused = eventHandler.isSearchFocused();
        boolean empty = eventHandler.getSearchQuery().isEmpty();
        String displayText = empty ? "Search modules..." : eventHandler.getSearchQuery();
        Color textColor = empty ? Theme.TEXT_MUTED : Theme.TEXT;
        int textX = searchX + 10;
        int textY = searchY + (SEARCH_BAR_HEIGHT - 12) / 2 + 2;

        String clippedText = displayText;
        float maxTextWidth = SEARCH_BAR_WIDTH - 20;
        while (smallFont.getStringWidth(clippedText) > maxTextWidth && clippedText.length() > 0) {
            clippedText = clippedText.substring(0, clippedText.length() - 1);
        }

        if (focused) {
            RenderUtils.drawRoundedBorder(context, searchX, searchY, SEARCH_BAR_WIDTH, SEARCH_BAR_HEIGHT, 8, 1,
                Theme.rgb(Theme.alpha(Theme.ACCENT, 200), anim));
        }
        RenderUtils.drawRoundedRect(context, searchX, searchY, SEARCH_BAR_WIDTH, SEARCH_BAR_HEIGHT, 8,
            Theme.rgb(Theme.alpha(Theme.FIELD, 210), anim));
        smallFont.drawString(matrices, clippedText, textX, textY - 4, Theme.alpha(textColor, (int)(anim * 255)));

        if (focused && !empty) {
            long currentTime = System.currentTimeMillis();
            if ((currentTime - lastCursorBlink) % 1000 < 500) {
                int cursorX = textX + (int)smallFont.getStringWidth(clippedText);
                context.fill(cursorX, textY - 1, cursorX + 1, textY + 11, Theme.rgb(Theme.ACCENT_LIGHT, anim));
            }
        }
    }

    private void renderSidebar(DrawContext context, int x, int y, int height, int mouseX, int mouseY) {
        float anim = animationManager.getGuiAnimation();

        // Rounded inset panel behind the category list.
        RenderUtils.drawRoundedRect(context, x + 8, y + HEADER_HEIGHT + 4, SIDEBAR_WIDTH - 12, height - HEADER_HEIGHT - 12, 10,
            Theme.rgb(Theme.alpha(Theme.SIDEBAR, 150), anim));

        int sidebarX = x;
        int sidebarY = y + HEADER_HEIGHT;

        MatrixStack matrices = context.getMatrices();
        int categoryY = sidebarY + PADDING;

        for (Category category : Category.values()) {
            boolean isSelected = category == eventHandler.getSelectedCategory();
            boolean isHovered = mouseX >= sidebarX && mouseX <= sidebarX + SIDEBAR_WIDTH &&
                              mouseY >= categoryY && mouseY <= categoryY + 35;

            float targetAnimation = isSelected ? 1f : (isHovered ? 0.35f : 0f);
            float currentAnimation = animationManager.getCategoryAnimation(category);
            float newAnimation = animationManager.smooth(currentAnimation, targetAnimation, 14f);
            animationManager.setCategoryAnimation(category, newAnimation);

            int pillX = sidebarX + 14;
            int pillW = SIDEBAR_WIDTH - 24;
            if (newAnimation > 0.01f) {
                RenderUtils.drawRoundedRectVGradient(context, pillX, categoryY, pillW, 35, 8,
                    Theme.rgb(Theme.alpha(Theme.ACCENT, (int)(120 * newAnimation)), anim),
                    Theme.rgb(Theme.alpha(Theme.ACCENT_DEEP, (int)(110 * newAnimation)), anim));
                RenderUtils.drawRoundedRect(context, pillX + 5, categoryY + 9, 3, 17, 1,
                    Theme.rgb(Theme.alpha(Theme.ACCENT_LIGHT, (int)(255 * Math.min(1f, newAnimation))), anim));
            }

            Color textColor = Theme.mix(Theme.TEXT_DIM, Theme.TEXT, newAnimation);
            regularFont.drawString(matrices, category.getName(), sidebarX + 28, categoryY + 13,
                Theme.alpha(textColor, (int)(anim * 255)));

            categoryY += 45;
        }
    }

    private void renderContent(DrawContext context, int x, int y, int width, int height, int mouseX, int mouseY) {
        float anim = animationManager.getGuiAnimation();

        // Rounded inset panel behind the module list.
        int panelX = x + 4;
        int panelY = y + HEADER_HEIGHT + 4;
        int panelW = width - 12;
        int panelH = height - HEADER_HEIGHT - 12;
        RenderUtils.drawRoundedRect(context, panelX, panelY, panelW, panelH, 10,
            Theme.rgb(Theme.alpha(Theme.CONTENT, 130), anim));

        MatrixStack matrices = context.getMatrices();

        context.enableScissor(panelX, panelY, panelX + panelW, panelY + panelH);

        if (eventHandler.getSelectedCategory() == Category.CONFIG) {
            renderConfigContent(context, x, y, width, height, mouseX, mouseY);
        } else {
            renderModuleContent(context, x, y, width, height, mouseX, mouseY);
        }

        context.disableScissor();
    }

    private void renderModuleContent(DrawContext context, int x, int y, int width, int height, int mouseX, int mouseY) {
        MatrixStack matrices = context.getMatrices();
        float guiAnim = animationManager.getGuiAnimation();

        List<Module> allModules;
        if (eventHandler.getSearchQuery().isEmpty()) {
            allModules = Volt.INSTANCE.getModuleManager().getModulesInCategory(eventHandler.getSelectedCategory());
        } else {
            allModules = Volt.INSTANCE.getModuleManager().getModules();
        }
        List<Module> modules = filterModulesBySearch(allModules);

        int moduleY = y + HEADER_HEIGHT + PADDING - eventHandler.getRenderScroll();
        int totalContentHeight = PADDING;

        for (Module module : modules) {
            int moduleHeight = MODULE_HEIGHT + 5;
            if (moduleExpanded.get(module)) {
                moduleHeight += (int)(animationManager.getDropdownAnimation(module) * SettingsRenderer.getModuleSettingsHeight(module, SETTING_HEIGHT, eventHandler));
            }

            totalContentHeight += moduleHeight;

            if (moduleY + moduleHeight < y + HEADER_HEIGHT) {
                moduleY += moduleHeight;
                continue;
            }

            if (moduleY > y + height) break;

            boolean isHovered = mouseX >= x + PADDING && mouseX <= x + width - PADDING &&
                              mouseY >= moduleY && mouseY <= moduleY + MODULE_HEIGHT;
            boolean isEnabled = module.isEnabled();
            boolean hasSettings = module.getSettings() != null && !module.getSettings().isEmpty();

            float targetAnimation = isEnabled ? 1f : (isHovered ? 0.2f : 0f);
            float currentAnimation = animationManager.getModuleAnimation(module);
            float newAnimation = animationManager.smooth(currentAnimation, targetAnimation, 12f);
            animationManager.setModuleAnimation(module, newAnimation);

            float targetDropdown = moduleExpanded.get(module) ? 1f : 0f;
            float currentDropdown = animationManager.getDropdownAnimation(module);
            float newDropdown = animationManager.smooth(currentDropdown, targetDropdown, 14f);
            animationManager.setDropdownAnimation(module, newDropdown);

            // Card: soft navy by default, glows violet as it turns on.
            float hoverMix = isHovered ? 1f : 0f;
            Color cardTop = Theme.mix(Theme.alpha(Theme.CARD, 150), Theme.alpha(Theme.CARD_HOVER, 190), hoverMix);
            Color cardBottom = Theme.mix(Theme.alpha(Theme.CARD, 120), Theme.alpha(Theme.CARD_HOVER, 170), hoverMix);
            float on = isEnabled ? newAnimation : 0f;
            cardTop = Theme.mix(cardTop, Theme.alpha(Theme.ACCENT, 150), on * 0.75f);
            cardBottom = Theme.mix(cardBottom, Theme.alpha(Theme.ACCENT_DEEP, 150), on * 0.75f);
            RenderUtils.drawRoundedRectVGradient(context, x + PADDING, moduleY, width - PADDING * 2, MODULE_HEIGHT, 8,
                Theme.rgb(cardTop, guiAnim), Theme.rgb(cardBottom, guiAnim));

            if (on > 0.02f) {
                RenderUtils.drawRoundedRect(context, x + PADDING + 6, moduleY + 8, 3, MODULE_HEIGHT - 16, 1,
                    Theme.rgb(Theme.alpha(Theme.ACCENT_LIGHT, (int)(255 * on)), guiAnim));
            }

            Color textColor = Theme.mix(Theme.TEXT_DIM, Theme.TEXT, Math.min(1f, newAnimation * 1.2f));
            regularFont.drawString(matrices, module.getName(), x + PADDING + 16, moduleY + 8, textColor);
            if (hasSettings) {
                boolean expanded = moduleExpanded.get(module);
                UIRenderer.renderDropdownArrow(context, x + width - PADDING - 30, moduleY + MODULE_HEIGHT / 2,
                    expanded, expanded ? Theme.ACCENT_LIGHT : Theme.TEXT_MUTED);
            }

            if (module.getDescription() != null && !module.getDescription().isEmpty()) {
                float descWidth = smallFont.getStringWidth(module.getDescription());
                float maxDescWidth = width - PADDING - 30 - 100;
                if (descWidth > maxDescWidth) {
                    String truncated = module.getDescription();
                    while (smallFont.getStringWidth(truncated + "...") > maxDescWidth && truncated.length() > 1) {
                        truncated = truncated.substring(0, truncated.length() - 1);
                    }
                    truncated += "...";
                    descWidth = smallFont.getStringWidth(truncated);
                    smallFont.drawString(matrices, truncated,
                        x + width - PADDING - descWidth - (hasSettings ? 40 : 10), moduleY + 10, Theme.TEXT_MUTED);
                } else {
                    smallFont.drawString(matrices, module.getDescription(),
                        x + width - PADDING - descWidth - (hasSettings ? 40 : 10), moduleY + 10, Theme.TEXT_MUTED);
                }
            }

            moduleY += MODULE_HEIGHT + 5;

            if (hasSettings && newDropdown > 0.05f) {
                int settingsHeight = renderModuleSettings(context, module, x, moduleY, width, newDropdown);
                moduleY += (int)(newDropdown * settingsHeight);
            }
        }

        totalContentHeight += PADDING;
        int visibleHeight = height - HEADER_HEIGHT;
        eventHandler.updateMaxScrollOffset(totalContentHeight, visibleHeight);
    }

    private void renderConfigContent(DrawContext context, int x, int y, int width, int height, int mouseX, int mouseY) {
        MatrixStack matrices = context.getMatrices();
        float guiAnim = animationManager.getGuiAnimation();
        int startY = y + HEADER_HEIGHT + PADDING - eventHandler.getRenderScroll();
        int currentY = startY;

        titleFont.drawString(matrices, "Config Manager", x + PADDING, currentY, Theme.TEXT);
        currentY += 50;

        if (configNameFocused) {
            RenderUtils.drawRoundedBorder(context, x + PADDING, currentY, width - PADDING * 2, 30, 8, 1,
                Theme.rgb(Theme.alpha(Theme.ACCENT, 200), guiAnim));
        }
        RenderUtils.drawRoundedRect(context, x + PADDING, currentY, width - PADDING * 2, 30, 8,
            Theme.rgb(Theme.alpha(Theme.FIELD, 210), guiAnim));
        String displayText = configName.isEmpty() ? "Enter config name..." : configName;
        Color textColor = configName.isEmpty() ? Theme.TEXT_MUTED : Theme.TEXT;
        regularFont.drawString(matrices, displayText, x + PADDING + 10, currentY + 8, textColor);

        if (configNameFocused && !configName.isEmpty()) {
            long currentTime = System.currentTimeMillis();
            if ((currentTime - lastCursorBlink) % 1000 < 500) {
                int cursorX = x + PADDING + 10 + (int)regularFont.getStringWidth(configName);
                context.fill(cursorX, currentY + 6, cursorX + 1, currentY + 24, Theme.ACCENT_LIGHT.getRGB());
            }
        }
        currentY += 40;

        renderConfigButton(context, x + PADDING, currentY, 80, 25, "Save", Theme.ACCENT, mouseX, mouseY);
        renderConfigButton(context, x + PADDING + 90, currentY, 80, 25, "Load", Theme.ACCENT_BLUE, mouseX, mouseY);
        renderConfigButton(context, x + PADDING + 180, currentY, 80, 25, "Delete", new Color(196, 70, 120), mouseX, mouseY);
        currentY += 40;

        regularFont.drawString(matrices, "Available Configs:", x + PADDING, currentY, Theme.TEXT_DIM);
        currentY += 25;

        for (String config : configs) {
            boolean isHovered = mouseX >= x + PADDING && mouseX <= x + width - PADDING &&
                              mouseY >= currentY && mouseY <= currentY + 25;
            boolean isSelected = config.equals(selectedConfig);

            Color bgColor = isSelected ? Theme.alpha(Theme.ACCENT, 130) :
                          (isHovered ? Theme.alpha(Theme.CARD_HOVER, 190) : Theme.alpha(Theme.CARD, 140));
            RenderUtils.drawRoundedRect(context, x + PADDING, currentY, width - PADDING * 2, 25, 7,
                Theme.rgb(bgColor, guiAnim));

            Color itemTextColor = isSelected ? Theme.TEXT : Theme.TEXT_DIM;
            regularFont.drawString(matrices, config, x + PADDING + 10, currentY + 6, itemTextColor);

            currentY += 30;
        }

        int totalContentHeight = currentY - startY + PADDING;
        int visibleHeight = height - HEADER_HEIGHT;
        eventHandler.updateMaxScrollOffset(totalContentHeight, visibleHeight);
    }

    private void renderConfigButton(DrawContext context, int x, int y, int width, int height, String text, Color baseColor, int mouseX, int mouseY) {
        boolean isHovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
        Color top = isHovered ? baseColor.brighter() : baseColor;
        Color bottom = Theme.mix(top, Theme.BG_BOTTOM, 0.35f);
        RenderUtils.drawRoundedRectVGradient(context, x, y, width, height, 7,
            Theme.rgb(Theme.alpha(top, 235), animationManager.getGuiAnimation()),
            Theme.rgb(Theme.alpha(bottom, 235), animationManager.getGuiAnimation()));

        int textX = x + (width - (int)smallFont.getStringWidth(text)) / 2;
        int textY = y + (height - 12) / 2;
        smallFont.drawString(context.getMatrices(), text, textX, textY, Color.WHITE);
    }

    private List<Module> filterModulesBySearch(List<Module> modules) {
        return SearchUtils.filterModulesBySearch(modules, eventHandler.getSearchQuery());
    }

    private int renderModuleSettings(DrawContext context, Module module, int x, int moduleY, int width, float animation) {
        return SettingsRenderer.renderModuleSettings(context, module, x, moduleY, width, animation, smallFont, eventHandler.getDropdownExpanded(), eventHandler);
    }

    private boolean handleColorPickerClicks(double mouseX, double mouseY, int button) {
        return colorPickerManager.handleColorPickerClicks(mouseX, mouseY, button);
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button < 0 || button > 8) return false;
        
        if (eventHandler.getSelectedCategory() == Category.CONFIG && handleConfigClick(mouseX, mouseY, button)) {
            return true;
        }
        
        if (handleColorPickerClicks(mouseX, mouseY, button)) {
            return true;
        }
        
        List<Module> allModules;
        if (eventHandler.getSearchQuery().isEmpty()) {
            allModules = Volt.INSTANCE.getModuleManager().getModulesInCategory(eventHandler.getSelectedCategory());
        } else {
            allModules = Volt.INSTANCE.getModuleManager().getModules();
        }
        List<Module> modules = filterModulesBySearch(allModules);
        
        return eventHandler.handleMouseClick(mouseX, mouseY, button, width, height, modules) || 
               super.mouseClicked(mouseX, mouseY, button);
    }
    
    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (colorPickerManager.handleColorPickerDrag(mouseX, mouseY, button, deltaX, deltaY)) {
            return true;
        }
        
        return eventHandler.handleMouseDrag(mouseX, mouseY, button, deltaX, deltaY, width, height);
    }
    
    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (colorPickerManager.handleColorPickerRelease(mouseX, mouseY, button)) {
            return true;
        }
        
        return eventHandler.handleMouseRelease(mouseX, mouseY, button);
     }
    
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return eventHandler.handleMouseScroll(mouseX, mouseY, horizontalAmount, verticalAmount, height) ||
               super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        
        if (configNameFocused) {
            if (keyCode == GLFW.GLFW_KEY_ENTER) {
                saveConfig();
                configNameFocused = false;
                return true;
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!configName.isEmpty()) {
                    configName = configName.substring(0, configName.length() - 1);
                }
                return true;
            } else if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                configNameFocused = false;
                return true;
            }
        }
        
        if (colorPickerManager.handleColorPickerKeyPress(keyCode)) {
            return true;
        }
        if (eventHandler.handleKeyPress(keyCode, scanCode, modifiers)) {
            return true;
        }
        
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            lastSelectedCategory = eventHandler.getSelectedCategory();
            lastScrollOffset = eventHandler.getScrollOffset();
            lastModuleExpanded.clear();
            lastModuleExpanded.putAll(moduleExpanded);
            close();
            return true;
        }
        
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (configNameFocused && chr >= 32 && chr < 127) {
            if (configName.length() < 20) {
                configName += chr;
            }
            return true;
        }
        if (colorPickerManager.handleColorPickerCharTyped(chr)) return true;
        return eventHandler.handleCharTyped(chr, modifiers) || super.charTyped(chr, modifiers);
    }
    
    @Override
    public void close() {
        animationManager.startClosingAnimation();
    }
    
    private void loadConfigs() {
        configs.clear();
        File profileDir = Volt.INSTANCE.getProfileManager().getProfileDir();
        if (profileDir.exists() && profileDir.isDirectory()) {
            File[] files = profileDir.listFiles((dir, name) -> name.endsWith(".json"));
            if (files != null) {
                for (File file : files) {
                    configs.add(file.getName().replace(".json", ""));
                }
            }
        }
    }
    
    private boolean handleConfigClick(double mouseX, double mouseY, int button) {
        int screenWidth = width;
        int screenHeight = height;
        int containerX = (screenWidth - CONTAINER_WIDTH) / 2;
        int containerY = (screenHeight - 500) / 2;
        int contentX = containerX + SIDEBAR_WIDTH;
        int contentY = containerY + HEADER_HEIGHT + PADDING - eventHandler.getRenderScroll();
        
        int inputY = contentY + 50;
        if (mouseY >= inputY && mouseY <= inputY + 30) {
            configNameFocused = true;
            return true;
        }
        
        int buttonY = inputY + 40;
        if (mouseY >= buttonY && mouseY <= buttonY + 25) {
            if (mouseX >= contentX + PADDING && mouseX <= contentX + PADDING + 80) {
                saveConfig();
                return true;
            } else if (mouseX >= contentX + PADDING + 90 && mouseX <= contentX + PADDING + 170) {
                loadConfig();
                return true;
            } else if (mouseX >= contentX + PADDING + 180 && mouseX <= contentX + PADDING + 260) {
                deleteConfig();
                return true;
            }
        }
        
        int listY = buttonY + 65;
        for (String config : configs) {
            if (mouseY >= listY && mouseY <= listY + 25) {
                selectedConfig = config;
                configName = config;
                return true;
            }
            listY += 30;
        }
        
        configNameFocused = false;
        return false;
    }
    
    private void saveConfig() {
        if (!configName.trim().isEmpty()) {
            Volt.INSTANCE.getProfileManager().saveProfile(configName.trim(), true);
            loadConfigs();
            selectedConfig = configName.trim();
        }
    }
    
    private void loadConfig() {
        if (!selectedConfig.isEmpty()) {
            Volt.INSTANCE.getProfileManager().loadProfile(selectedConfig);
        }
    }
    
    private void deleteConfig() {
        if (!selectedConfig.isEmpty()) {
            File configFile = new File(Volt.INSTANCE.getProfileManager().getProfileDir(), selectedConfig + ".json");
            if (configFile.exists() && configFile.delete()) {
                loadConfigs();
                selectedConfig = "";
                configName = "";
            }
        }
    }
}