package com.volt.gui.components;

import com.volt.gui.Theme;
import com.volt.module.Module;
import com.volt.module.setting.*;
import com.volt.utils.font.fonts.FontRenderer;
import com.volt.gui.components.ColorPicker;
import com.volt.gui.events.GuiEventHandler;
import com.volt.utils.render.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.MinecraftClient;

import java.awt.Color;
import java.util.Map;
import java.util.HashMap;

public class SettingsRenderer {
    private static final int SETTING_HEIGHT = 28;

    public static int renderModuleSettings(DrawContext context, Module module, int x, int moduleY, int width, float animation, FontRenderer smallFont, Map<ModeSetting, Boolean> dropdownExpanded, GuiEventHandler eventHandler) {
        if (module.getSettings() == null || module.getSettings().isEmpty()) {
            return 0;
        }

        MatrixStack matrices = context.getMatrices();

        int settingsHeight = module.getSettings().size() * SETTING_HEIGHT;
        int animatedHeight = (int) (settingsHeight * animation);

        RenderUtils.drawRoundedRect(context, x + 18, moduleY, width - 36, animatedHeight, 8, Theme.alpha(Theme.SETTINGS_BG, 200).getRGB());

        int maxControlWidth = Math.min(100, width - 78);

        // Clip rows to the panel while it opens/closes so nothing spills out of the rounded box.
        context.enableScissor(x + 18, moduleY, x + width - 18, moduleY + animatedHeight);

        int settingY = moduleY + 5;
        for (Setting setting : module.getSettings()) {
            String settingName = setting.getName();
            float maxNameWidth = width - 58 - maxControlWidth - 20;
            if (setting instanceof NumberSetting) {
                maxNameWidth -= 34; // room for the value readout that sits left of the slider
            }
            while (smallFont.getStringWidth(settingName + "...") > maxNameWidth && settingName.length() > 1) {
                settingName = settingName.substring(0, settingName.length() - 1);
            }
            if (smallFont.getStringWidth(settingName) > maxNameWidth) settingName += "...";

            smallFont.drawString(matrices, settingName, x + 28, settingY + 5, Theme.TEXT_DIM);

            renderSettingControl(context, setting, x, settingY, width, maxControlWidth, null, eventHandler);

            settingY += SETTING_HEIGHT;
            if (settingY > moduleY + animatedHeight) break;
        }

        context.disableScissor();

        for (int i = 0; i < module.getSettings().size(); i++) {
            Setting setting = module.getSettings().get(i);
            if (setting instanceof ModeSetting modeSetting && dropdownExpanded.getOrDefault(modeSetting, false)) {
                int controlX = x + width - 18 - maxControlWidth - 12;
                int controlY = moduleY + 5 + i * SETTING_HEIGHT + (SETTING_HEIGHT - 15) / 2;
                int controlWidth = maxControlWidth;
                int controlHeight = 15;

                renderModeDropdownOverlay(context, modeSetting, controlX, controlY, controlWidth, controlHeight);
            }
        }

        return settingsHeight;
    }

    private static void renderModeDropdownOverlay(DrawContext context, ModeSetting modeSetting, int x, int y, int width, int height) {
        String currentMode = modeSetting.getMode();
        int count = modeSetting.getModes().size();

        // One rounded popup behind the header field and all options.
        RenderUtils.drawRoundedBorder(context, x, y, width, height * (count + 1), 5, 1, Theme.alpha(Theme.BORDER, 150).getRGB());
        RenderUtils.drawRoundedRect(context, x, y, width, height * (count + 1), 5, Theme.alpha(new Color(20, 18, 54), 252).getRGB());

        context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, currentMode, x + 5, y + 3, Theme.TEXT.getRGB());
        drawChevron(context, x + width - 12, y + height / 2, true, Theme.TEXT_DIM);

        int optionY = y + height;
        for (String mode : modeSetting.getModes()) {
            boolean isSelected = mode.equals(currentMode);

            if (isSelected) {
                RenderUtils.drawRoundedRect(context, x + 2, optionY + 1, width - 4, height - 2, 4, Theme.alpha(Theme.ACCENT, 170).getRGB());
            }

            String text = mode.length() > 8 ? mode.substring(0, 8) + "..." : mode;
            Color textColor = isSelected ? Theme.TEXT : Theme.TEXT_DIM;
            context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, text, x + 5, optionY + 3, textColor.getRGB());

            optionY += height;
        }
    }

    private static void drawChevron(DrawContext context, int arrowX, int arrowY, boolean down, Color color) {
        int rgb = color.getRGB();
        if (down) {
            context.fill(arrowX, arrowY - 2, arrowX + 5, arrowY - 1, rgb);
            context.fill(arrowX + 1, arrowY - 1, arrowX + 4, arrowY, rgb);
            context.fill(arrowX + 2, arrowY, arrowX + 3, arrowY + 1, rgb);
        } else {
            context.fill(arrowX + 2, arrowY - 2, arrowX + 3, arrowY + 1, rgb);
            context.fill(arrowX + 1, arrowY - 1, arrowX + 4, arrowY, rgb);
            context.fill(arrowX, arrowY, arrowX + 5, arrowY + 1, rgb);
        }
    }

    public static int renderModuleSettingsInGrid(DrawContext context, Module module, int x, int moduleY, int width, float animation, FontRenderer smallFont) {
        if (module.getSettings() == null || module.getSettings().isEmpty()) {
            return 0;
        }

        MatrixStack matrices = context.getMatrices();
        int rows = (int) Math.ceil(module.getSettings().size() / 2.0);
        int settingsHeight = rows * SETTING_HEIGHT;
        int animatedHeight = (int) (settingsHeight * animation);

        RenderUtils.drawRoundedRect(context, x + 18, moduleY, width - 36, animatedHeight, 8, Theme.alpha(Theme.SETTINGS_BG, 200).getRGB());

        int columnWidth = (width - 58) / 2;
        int maxNameWidth = columnWidth - 120;

        for (int i = 0; i < module.getSettings().size(); i++) {
            var setting = module.getSettings().get(i);

            int row = i / 2;
            int col = i % 2;
            int settingX = x + 28 + col * columnWidth;
            int settingY = moduleY + 5 + row * SETTING_HEIGHT;

            String settingName = setting.getName();
            float nameWidth = smallFont.getStringWidth(settingName);
            if (nameWidth > maxNameWidth) {
                while (smallFont.getStringWidth(settingName + "...") > maxNameWidth && settingName.length() > 1) {
                    settingName = settingName.substring(0, settingName.length() - 1);
                }
                settingName += "...";
            }
            smallFont.drawString(matrices, settingName,
                    settingX, settingY + 5, Theme.TEXT_DIM);

            renderSettingControlInGrid(context, setting, settingX, settingY, columnWidth);
        }

        return settingsHeight;
    }

    private static void renderSettingControl(DrawContext context, Setting setting, int x, int settingY, int width, int maxControlWidth, Map<ModeSetting, Boolean> dropdownExpanded, GuiEventHandler eventHandler) {
        int controlX = x + width - 18 - maxControlWidth - 12;
        int controlY = settingY + (SETTING_HEIGHT - 15) / 2;
        int controlWidth = maxControlWidth;
        int controlHeight = 15;

        renderSettingControlCommon(context, setting, controlX, controlY, controlWidth, controlHeight, dropdownExpanded, eventHandler);
    }

    private static void renderSettingControlInGrid(DrawContext context, Setting setting, int settingX, int settingY, int columnWidth) {
        int maxControlWidth = Math.min(80, columnWidth - 20);
        int controlX = settingX + columnWidth - maxControlWidth - 10;
        int controlY = settingY + (SETTING_HEIGHT - 15) / 2;
        int controlWidth = maxControlWidth;
        int controlHeight = 15;

        renderSettingControlCommon(context, setting, controlX, controlY, controlWidth, controlHeight, null, null);
    }

    private static void renderSettingControlCommon(DrawContext context, Setting setting, int controlX, int controlY, int controlWidth, int controlHeight, Map<ModeSetting, Boolean> dropdownExpanded, GuiEventHandler eventHandler) {
        Map<ColorSetting, ColorPicker> colorPickers = eventHandler != null ? eventHandler.getColorPickers() : new HashMap<>();
        switch (setting) {
            case BooleanSetting booleanSetting -> {
                boolean enabled = booleanSetting.getValue();
                Color borderColor = enabled ? Theme.ACCENT_LIGHT : Theme.alpha(Theme.BORDER, 180);
                Color fillColor = enabled ? Theme.ACCENT : Theme.alpha(Theme.FIELD, 230);

                int checkboxSize = 12;
                UIRenderer.renderCheckbox(context, controlX, controlY + 2, checkboxSize, enabled, borderColor, fillColor);
            }

            case NumberSetting numberSetting -> {
                double min = numberSetting.getMin();
                double max = numberSetting.getMax();
                double value = numberSetting.getValue();
                double normalized = (value - min) / (max - min);

                int sliderHeight = 6;
                int sliderY = controlY + (controlHeight - sliderHeight) / 2;
                UIRenderer.renderSlider(context, controlX, sliderY, controlWidth, sliderHeight, normalized,
                        Theme.alpha(Theme.FIELD, 255), Theme.ACCENT);

                String valueText = String.valueOf(value);
                if (valueText.endsWith(".0")) {
                    valueText = valueText.substring(0, valueText.length() - 2);
                }
                int valueWidth = MinecraftClient.getInstance().textRenderer.getWidth(valueText);
                context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, valueText,
                        controlX - 8 - valueWidth, controlY + 3, Theme.TEXT_DIM.getRGB());
            }

            case ModeSetting modeSetting -> {
                String currentMode = modeSetting.getMode();
                String displayText = currentMode.length() > 8 ? currentMode.substring(0, 8) + "..." : currentMode;

                RenderUtils.drawRoundedRect(context, controlX, controlY, controlWidth, controlHeight, 5,
                        Theme.alpha(Theme.FIELD, 240).getRGB());

                context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, displayText,
                        controlX + 5, controlY + 3, Theme.TEXT.getRGB());

                int arrowX = controlX + controlWidth - 12;
                int arrowY = controlY + controlHeight / 2;
                boolean isExpanded = dropdownExpanded != null && dropdownExpanded.getOrDefault(modeSetting, false);

                drawChevron(context, arrowX, arrowY, !isExpanded, Theme.TEXT_DIM);

                if (isExpanded) {
                    int count = modeSetting.getModes().size();
                    RenderUtils.drawRoundedRect(context, controlX, controlY + controlHeight, controlWidth, controlHeight * count, 5,
                            Theme.alpha(new Color(20, 18, 54), 252).getRGB());
                    int optionY = controlY + controlHeight;
                    for (String mode : modeSetting.getModes()) {
                        boolean isSelected = mode.equals(currentMode);
                        if (isSelected) {
                            RenderUtils.drawRoundedRect(context, controlX + 2, optionY + 1, controlWidth - 4, controlHeight - 2, 4,
                                    Theme.alpha(Theme.ACCENT, 170).getRGB());
                        }

                        String optionText = mode.length() > 8 ? mode.substring(0, 8) + "..." : mode;
                        Color textColor = isSelected ? Theme.TEXT : Theme.TEXT_DIM;
                        context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, optionText,
                                controlX + 5, optionY + 3, textColor.getRGB());

                        optionY += controlHeight;
                    }
                }
            }

            case KeybindSetting keybindSetting -> {
                String keyText = keybindSetting.isListening() ? "..." : com.volt.utils.keybinding.KeyUtils.getKey(keybindSetting.getKeyCode());
                Color bgColor = keybindSetting.isListening() ? Theme.alpha(Theme.ACCENT, 200) : Theme.alpha(Theme.FIELD, 240);

                RenderUtils.drawRoundedRect(context, controlX, controlY, controlWidth, controlHeight, 5, bgColor.getRGB());

                context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, "Bind: " + keyText,
                        controlX + 5, controlY + 3, Theme.TEXT.getRGB());
            }

            case ColorSetting colorSetting -> {
                Color currentColor = colorSetting.getValue();

                RenderUtils.drawRoundedRect(context, controlX, controlY, controlWidth, controlHeight, 5,
                        Theme.alpha(Theme.FIELD, 240).getRGB());

                int previewSize = Math.min(controlHeight - 2, 12);
                int previewX = controlX + controlWidth - previewSize - 2;
                int previewY = controlY + (controlHeight - previewSize) / 2;

                if (colorSetting.isHasAlpha()) {
                    renderCheckerboard(context, previewX, previewY, previewSize, previewSize);
                }

                RenderUtils.drawRoundedRect(context, previewX - 1, previewY - 1, previewSize + 2, previewSize + 2, 4,
                        Theme.alpha(Theme.BORDER, 200).getRGB());
                if (colorSetting.isHasAlpha()) {
                    context.fill(previewX, previewY, previewX + previewSize, previewY + previewSize, currentColor.getRGB());
                } else {
                    RenderUtils.drawRoundedRect(context, previewX, previewY, previewSize, previewSize, 3, currentColor.getRGB());
                }

                context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, "Color (Click)",
                        controlX + 5, controlY + 3, Theme.TEXT_DIM.getRGB());
            }

            default -> {
            }
        }
    }

    private static void renderCheckerboard(DrawContext context, int x, int y, int width, int height) {
        int checkSize = 4;
        for (int i = 0; i < width; i += checkSize) {
            for (int j = 0; j < height; j += checkSize) {
                boolean isLight = ((i / checkSize) + (j / checkSize)) % 2 == 0;
                Color checkColor = isLight ? new Color(200, 200, 215) : new Color(140, 140, 165);

                int checkWidth = Math.min(checkSize, width - i);
                int checkHeight = Math.min(checkSize, height - j);

                context.fill(x + i, y + j, x + i + checkWidth, y + j + checkHeight, checkColor.getRGB());
            }
        }
    }

    public static int getModuleSettingsHeight(Module module, int settingHeight, GuiEventHandler eventHandler) {
        if (module.getSettings() == null || module.getSettings().isEmpty()) {
            return 0;
        }

        int totalHeight = module.getSettings().size() * settingHeight;

        if (eventHandler != null) {
            for (Setting setting : module.getSettings()) {
                if (setting instanceof ColorSetting colorSetting && eventHandler.getColorPickerExpanded().getOrDefault(colorSetting, false)) {
                    totalHeight += 130;
                }
            }
        }

        return totalHeight;
    }
}
