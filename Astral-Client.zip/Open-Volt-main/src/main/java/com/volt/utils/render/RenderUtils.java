package com.volt.utils.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.VertexSorter;
import com.volt.Volt;
import lombok.experimental.UtilityClass;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;

import java.awt.*;

@UtilityClass
public final class RenderUtils {
    public static VertexSorter vertexSorter;
    public static boolean rendering3D = true;

    public static void unscaledProjection() {
        vertexSorter = RenderSystem.getVertexSorting();
        RenderSystem.setProjectionMatrix(new Matrix4f().setOrtho(0, Volt.mc.getWindow().getFramebufferWidth(), Volt.mc.getWindow().getFramebufferHeight(), 0, 1000, 21000), VertexSorter.BY_Z);
        rendering3D = false;
    }

    public static void scaledProjection() {
        RenderSystem.setProjectionMatrix(new Matrix4f().setOrtho(0, (float) (Volt.mc.getWindow().getFramebufferWidth() / Volt.mc.getWindow().getScaleFactor()), (float) (Volt.mc.getWindow().getFramebufferHeight() / Volt.mc.getWindow().getScaleFactor()), 0, 1000, 21000), vertexSorter);
        rendering3D = true;
    }

    public static void renderOutline(MatrixStack matrices, Box box, Color color) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

        float r = color.getRed() / 255.0f;
        float g = color.getGreen() / 255.0f;
        float b = color.getBlue() / 255.0f;
        float a = color.getAlpha() / 255.0f;

        float minX = (float) box.minX;
        float minY = (float) box.minY;
        float minZ = (float) box.minZ;
        float maxX = (float) box.maxX;
        float maxY = (float) box.maxY;
        float maxZ = (float) box.maxZ;

        buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);

        buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);

        buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);

        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }
    public static void renderFilled(MatrixStack matrices, Box box, Color color) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

        float r = color.getRed() / 255.0f;
        float g = color.getGreen() / 255.0f;
        float b = color.getBlue() / 255.0f;
        float a = color.getAlpha() / 255.0f;

        float minX = (float) box.minX;
        float minY = (float) box.minY;
        float minZ = (float) box.minZ;
        float maxX = (float) box.maxX;
        float maxY = (float) box.maxY;
        float maxZ = (float) box.maxZ;

        buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);

        buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);

        buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);

        buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);

        buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);

        buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
        buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);

        BufferRenderer.drawWithGlobalProgram(buffer.end());
}


    public static void drawRoundedRect(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        drawRoundedRectVGradient(context, x, y, width, height, radius, color, color);
    }

    public static void drawRoundedRectGradient(DrawContext context, int x, int y, int width, int height, int radius, int colorTop, int colorBottom) {
        drawRoundedRectVGradient(context, x, y, width, height, radius, colorTop, colorBottom);
    }

    /**
     * Anti-aliased rounded rectangle with an optional vertical gradient.
     * Drawn as horizontal spans (a handful of fills per rect instead of one fill per pixel),
     * which keeps edges clean and the GUI cheap to render.
     */
    public static void drawRoundedRectVGradient(DrawContext context, int x, int y, int width, int height, int radius, int colorTop, int colorBottom) {
        drawRoundedRectCorners(context, x, y, width, height, radius, true, true, colorTop, colorBottom);
    }

    /** Same as above, but the top and/or bottom pair of corners can be left square. */
    public static void drawRoundedRectCorners(DrawContext context, int x, int y, int width, int height, int radius,
                                              boolean roundTop, boolean roundBottom, int colorTop, int colorBottom) {
        if (width <= 0 || height <= 0) return;

        int r = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
        int rt = roundTop ? r : 0;
        int rb = roundBottom ? r : 0;
        boolean flat = colorTop == colorBottom;
        float span = height <= 1 ? 1f : (float) (height - 1);

        for (int row = 0; row < rt; row++) {
            drawArcRow(context, x, y + row, width, r, row, flat ? colorTop : interpolateColor(colorTop, colorBottom, row / span));
        }

        int midTop = rt;
        int midBottom = height - rb;
        if (midBottom > midTop) {
            if (flat) {
                context.fill(x, y + midTop, x + width, y + midBottom, colorTop);
            } else {
                int c1 = interpolateColor(colorTop, colorBottom, midTop / span);
                int c2 = interpolateColor(colorTop, colorBottom, (midBottom - 1) / span);
                context.fillGradient(x, y + midTop, x + width, y + midBottom, c1, c2);
            }
        }

        for (int row = Math.max(midBottom, rt); row < height; row++) {
            drawArcRow(context, x, y + row, width, r, height - 1 - row, flat ? colorTop : interpolateColor(colorTop, colorBottom, row / span));
        }
    }

    /** One scanline of a rounded corner region: {@code distToEdge} rows away from the straight top/bottom edge. */
    private static void drawArcRow(DrawContext context, int x, int py, int width, int r, int distToEdge, int color) {
        float dy = r - (distToEdge + 0.5f);
        float inset = r - (float) Math.sqrt(Math.max(0f, (float) r * r - dy * dy));
        int fullStart = (int) Math.ceil(inset);

        if (fullStart * 2 < width) {
            context.fill(x + fullStart, py, x + width - fullStart, py + 1, color);
        }

        float coverage = fullStart - inset;
        if (fullStart > 0 && coverage > 0.02f && (fullStart - 1) * 2 < width) {
            int a = (int) (((color >> 24) & 0xFF) * coverage);
            int edge = (a << 24) | (color & 0x00FFFFFF);
            context.fill(x + fullStart - 1, py, x + fullStart, py + 1, edge);
            context.fill(x + width - fullStart, py, x + width - fullStart + 1, py + 1, edge);
        }
    }

    /** Thin rounded outline (drawn as a slightly larger rounded rect under the panel it surrounds). */
    public static void drawRoundedBorder(DrawContext context, int x, int y, int width, int height, int radius, int thickness, int color) {
        drawRoundedRectVGradient(context, x - thickness, y - thickness, width + thickness * 2, height + thickness * 2, radius + thickness, color, color);
    }

    private static void drawRoundedCorner(DrawContext context, int centerX, int centerY, int radius, int color, int corner) {
        float radiusF = (float) radius;

        for (int i = 0; i < radius; i++) {
            for (int j = 0; j < radius; j++) {
                float distance = (float) Math.sqrt(i * i + j * j);

                if (distance <= radiusF) {
                    int pixelX = centerX;
                    int pixelY = centerY;

                    switch (corner) {
                        case 0:
                            pixelX = centerX - i;
                            pixelY = centerY - j;
                            break;
                        case 1:
                            pixelX = centerX + i;
                            pixelY = centerY - j;
                            break;
                        case 2:
                            pixelX = centerX - i;
                            pixelY = centerY + j;
                            break;
                        case 3:
                            pixelX = centerX + i;
                            pixelY = centerY + j;
                            break;
                    }

                    float alpha = 1.0f;
                    if (distance > radiusF - 1.0f) {
                        alpha = Math.max(0.0f, radiusF - distance);
                    }

                    int originalAlpha = (color >> 24) & 0xFF;
                    int newAlpha = (int) (originalAlpha * alpha);
                    int antiAliasedColor = (newAlpha << 24) | (color & 0x00FFFFFF);

                    context.fill(pixelX, pixelY, pixelX + 1, pixelY + 1, antiAliasedColor);
                }
            }
        }
    }

    public static void drawFilledCircle(DrawContext context, int centerX, int centerY, int radius, int color) {
        for (int y = -radius; y <= radius; y++) {
            for (int x = -radius; x <= radius; x++) {
                if (x * x + y * y <= radius * radius) {
                    context.fill(centerX + x, centerY + y, centerX + x + 1, centerY + y + 1, color);
                }
            }
        }
    }


    private static void drawRoundedCornerGradient(DrawContext context, int centerX, int centerY, int radius, int colorTop, int colorBottom, int corner) {
        float radiusF = (float) radius;

        for (int i = 0; i < radius; i++) {
            for (int j = 0; j < radius; j++) {
                float distance = (float) Math.sqrt(i * i + j * j);

                if (distance <= radiusF) {
                    int pixelX = centerX;
                    int pixelY = centerY;

                    switch (corner) {
                        case 0:
                            pixelX = centerX - i;
                            pixelY = centerY - j;
                            break;
                        case 1:
                            pixelX = centerX + i;
                            pixelY = centerY - j;
                            break;
                        case 2:
                            pixelX = centerX - i;
                            pixelY = centerY + j;
                            break;
                        case 3:
                            pixelX = centerX + i;
                            pixelY = centerY + j;
                            break;
                    }

                    float gradientFactor = (float) j / radius;
                    int interpolatedColor = interpolateColor(colorTop, colorBottom, gradientFactor);

                    float alpha = 1.0f;
                    if (distance > radiusF - 1.0f) {
                        alpha = Math.max(0.0f, radiusF - distance);
                    }

                    int originalAlpha = (interpolatedColor >> 24) & 0xFF;
                    int newAlpha = (int) (originalAlpha * alpha);
                    int antiAliasedColor = (newAlpha << 24) | (interpolatedColor & 0x00FFFFFF);

                    context.fill(pixelX, pixelY, pixelX + 1, pixelY + 1, antiAliasedColor);
                }
            }
        }
    }

    private static int interpolateColor(int color1, int color2, float factor) {
        int a1 = (color1 >> 24) & 0xFF;
        int r1 = (color1 >> 16) & 0xFF;
        int g1 = (color1 >> 8) & 0xFF;
        int b1 = color1 & 0xFF;

        int a2 = (color2 >> 24) & 0xFF;
        int r2 = (color2 >> 16) & 0xFF;
        int g2 = (color2 >> 8) & 0xFF;
        int b2 = color2 & 0xFF;

        int a = (int) (a1 + (a2 - a1) * factor);
        int r = (int) (r1 + (r2 - r1) * factor);
        int g = (int) (g1 + (g2 - g1) * factor);
        int b = (int) (b1 + (b2 - b1) * factor);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static void drawGlow(DrawContext context, int x, int y, int width, int height, int radius, int color, int glowRadius) {
        for (int i = 1; i <= glowRadius; i++) {
            int alpha = (int) (((color >> 24) & 0xFF) * (1.0f - (float) i / glowRadius) * 0.3f);
            int glowColor = (alpha << 24) | (color & 0x00FFFFFF);

            drawRoundedRect(context, x - i, y - i, width + (i * 2), height + (i * 2), radius + i, glowColor);
        }
    }

    public static void drawSmoothRect(DrawContext context, int x, int y, int width, int height, int color) {
        context.fill(x, y, x + width, y + height, color);

        int edgeColor = (color & 0x00FFFFFF) | (((color >> 24) & 0xFF) / 2 << 24);
        context.fill(x - 1, y, x, y + height, edgeColor);
        context.fill(x + width, y, x + width + 1, y + height, edgeColor);
        context.fill(x, y - 1, x + width, y, edgeColor);
        context.fill(x, y + height, x + width, y + height + 1, edgeColor);
    }

    public static void drawSmoothRoundedRect(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        drawRoundedRectVGradient(context, x, y, width, height, radius, color, color);
    }

    private static void drawSmoothRoundedCorner(DrawContext context, int centerX, int centerY, int radius, int color, int corner) {
        float radiusF = (float) radius;

        for (float i = 0; i < radius; i += 0.5f) {
            for (float j = 0; j < radius; j += 0.5f) {
                float distance = (float) Math.sqrt(i * i + j * j);

                if (distance <= radiusF) {
                    int pixelX = centerX;
                    int pixelY = centerY;

                    switch (corner) {
                        case 0:
                            pixelX = centerX - (int) i;
                            pixelY = centerY - (int) j;
                            break;
                        case 1:
                            pixelX = centerX + (int) i;
                            pixelY = centerY - (int) j;
                            break;
                        case 2:
                            pixelX = centerX - (int) i;
                            pixelY = centerY + (int) j;
                            break;
                        case 3:
                            pixelX = centerX + (int) i;
                            pixelY = centerY + (int) j;
                            break;
                    }

                    float coverage = calculateCoverage(i, j, radiusF);

                    if (coverage > 0) {
                        int originalAlpha = (color >> 24) & 0xFF;
                        int newAlpha = (int) (originalAlpha * coverage);
                        int antiAliasedColor = (newAlpha << 24) | (color & 0x00FFFFFF);

                        context.fill(pixelX, pixelY, pixelX + 1, pixelY + 1, antiAliasedColor);
                    }
                }
            }
        }
    }

    private static float calculateCoverage(float x, float y, float radius) {
        float distance = (float) Math.sqrt(x * x + y * y);

        if (distance <= radius - 1.0f) {
            return 1.0f;
        } else if (distance >= radius) {
            return 0.0f;
        } else {
            return Math.max(0.0f, radius - distance);
        }
    }

    public static void drawGradientRect(DrawContext context, int x, int y, int width, int height, int colorTop, int colorBottom) {
        context.fillGradient(x, y, x + width, y + height, colorTop, colorBottom);
    }
}